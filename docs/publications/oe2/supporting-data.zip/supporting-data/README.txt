Supplementary data for the OE2 manuscript

This archive contains the machine-readable tables, scenario trajectories, class mappings, metadata, and annual outputs associated with the supplementary PDF. Source rasters are not redistributed here; their providers and versions are identified in the manuscript and metadata.

Absolute paths from the author's computer were removed from JSON metadata. The input raster file names, grid characteristics, class mapping, scenario settings, and checksums are retained where available.
